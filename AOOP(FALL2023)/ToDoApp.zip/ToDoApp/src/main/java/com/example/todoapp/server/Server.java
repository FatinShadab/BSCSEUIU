package com.example.todoapp.server;

import com.example.todoapp.config.ServerConfig;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

public class Server {
    private static ServerSocket serverSocket;
    private static Boolean active = false;
    private static Thread requestListeningThread;
    private static Boolean internalError = false;
    private final static HashMap<InetAddress, ArrayList<String[]>> clientData = new HashMap<>();
    private final static ArrayList<String> serverLogs = new ArrayList<>();

    public static void startListening() throws IOException {
        if (!active) {
            serverLogs.add("[~] Server Started Listening at : " + LocalDate.now().toString());
            serverSocket = new ServerSocket(ServerConfig.serverPort);
            requestListeningThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (active) {
                        System.out.println("Called!");
                        try {
                            internalError = false;
                            System.out.println("waiting!");

                            Socket clientSocket = serverSocket.accept();
                            System.out.println("accepted!");

                            new Thread(() -> handleClientRequest(clientSocket)).start();
                        }
                        catch (SocketException se) {
                            if (!serverSocket.isClosed()) {
                                System.out.println("Socket closed. Stopping...");
                                break;
                            }
                        }
                        catch (Throwable throwable) {
                            System.out.println("[!] Exception : " + throwable.toString());
                            for (StackTraceElement t : throwable.getStackTrace()) {
                                System.out.println("\t[!] " + t.toString());
                            }
                            internalError = true;
                        }
                        System.out.println("Called! active : " + active);
                    }

                    System.out.println("Not Listening!");
                }
            });
            requestListeningThread.start();
            active = true;
        }

        if (internalError) throw new IOException();
    }

    public static void stopListening() throws Exception{
        serverLogs.add("[~] Server Stopped Listening at : " + LocalDate.now().toString());
        active = false;
        requestListeningThread = null;
        serverSocket.close();
    }

    private static void handleClientRequest(Socket clientSocket) {
        serverLogs.add("[~] Client joined, client address : " + clientSocket.getInetAddress().getHostAddress());
        try{
            ObjectInputStream inputStream = new ObjectInputStream(clientSocket.getInputStream());
            ObjectOutputStream outputStream = new ObjectOutputStream (clientSocket.getOutputStream());

            clientData.computeIfAbsent(clientSocket.getInetAddress(), k -> new ArrayList<String[]>());

            if (clientData.get(clientSocket.getInetAddress()) != null)
                clientData.get(clientSocket.getInetAddress()).add((String[]) inputStream.readObject());

            Collections.sort(
                    clientData.get(clientSocket.getInetAddress()),
                    new Comparator<String[]>() {
                        @Override
                        public int compare(String[] o1, String[] o2) {
                            LocalDate date1 = LocalDate.parse(o1[1]);
                            LocalDate date2 = LocalDate.parse(o2[1]);

                            return date1.compareTo(date2);
                        }
                    }
            );

            serverLogs.add("[~] Client : (" + clientSocket.getInetAddress().getHostAddress() + ") added task !");

            outputStream.writeObject(clientData.get(clientSocket.getInetAddress()));
        }
        catch (Throwable throwable) {
            System.out.println("[!] Exception : " + throwable.toString());
            for (StackTraceElement t : throwable.getStackTrace()) {
                System.out.println("\t[!] " + t.toString());
            }
        }
    }

    public static ArrayList<String> getServerLogs() {
        return serverLogs;
    }
}
