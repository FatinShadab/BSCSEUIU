package com.example.todoapp.controller.server;

import com.example.todoapp.server.Server;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

import java.net.URL;
import java.util.ResourceBundle;

public class ServerHomeSceneController implements Initializable {
    @FXML
    Button startButton, stopButton;
    private Boolean internalError = false;
    @FXML
    Pane internalServerErrorPane;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        stopButton.setDisable(true);
        internalServerErrorPane.setVisible(false);
    }

    public void onStartButtonClicked() {
        try {
            Server.startListening();
            stopButton.setDisable(false);
            startButton.setDisable(true);
        } catch (Throwable throwable) {
            System.out.println("[!] Exception : " + throwable.toString());
            for (StackTraceElement t : throwable.getStackTrace()) {
                System.out.println("\t[!] " + t.toString());
            }
            internalServerErrorPane.setVisible(true);
        }
    }

    public void onStopButtonClicked() {
        try {
            Server.stopListening();
            startButton.setDisable(false);
        } catch (Throwable throwable) {
            System.out.println("[!] Exception : " + throwable.toString());
            for (StackTraceElement t : throwable.getStackTrace()) {
                System.out.println("\t[!] " + t.toString());
            }
            internalServerErrorPane.setVisible(true);
        }
    }

    public void onServerErrorOkButtonClicked() {
        internalServerErrorPane.setVisible(false);
    }
}
